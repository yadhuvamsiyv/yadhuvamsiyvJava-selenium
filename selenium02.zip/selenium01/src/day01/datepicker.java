package day01;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class datepicker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String exp_mon_yr="May 2020", cur_mon_yr;
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
	dr.findElement(By.id("datepicker")).click();
	
	cur_mon_yr=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
	
	
	while(!cur_mon_yr.equals(exp_mon_yr)) {
		dr.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
		cur_mon_yr=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
	}
	
	
	List<WebElement> rb=dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//child::td"));
	for(WebElement sle:rb) {
		String date=sle.getText();
		if(date.equalsIgnoreCase("20")) {
			sle.click();
			break;
		}
	}
	}

}
