package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import library.utilities_01;

public class page_03 {

	static WebDriver dr;
	static DriverWait d;
	
	By user_id=By.xpath("//div[@id='Catalog']//following::input[2]");
	By new_pass=By.xpath("//div[@id='Catalog']//following::input[3]");
	By re_pass=By.xpath("//div[@id='Catalog']//following::input[4]");
	
	
	By f_name=By.xpath("//div[@id='Catalog']//following::input[5]");
	By l_name=By.xpath("//div[@id='Catalog']//following::input[6]");
	By email=By.xpath("//div[@id='Catalog']//following::input[7]");
	By phone=By.xpath("//div[@id='Catalog']//following::input[8]");
	By add_1=By.xpath("//div[@id='Catalog']//following::input[9]");
	By add_2=By.xpath("//div[@id='Catalog']//following::input[10]");
	By city=By.xpath("//div[@id='Catalog']//following::input[11]");
	By state=By.xpath("//div[@id='Catalog']//following::input[12]");
	By zip=By.xpath("//div[@id='Catalog']//following::input[13]");
	By country=By.xpath("//div[@id='Catalog']//following::input[14]");

	
	
	
	By mylist=By.xpath("//div[@id='Catalog']//following::input[15]");
	By mybanner=By.xpath("//input[@name='bannerOption']");
	By sve=By.xpath("//input[@id='save']");
	
	
	static page_03 ut= new page_03();
	
	public Ass_01(WebDriver dr) 
	{
		this.dr=dr;
	}
	
	public void set_userid(String ui) 
	{
		WebElement ur1=ut.waitforElement(user_id,20);
		ur1.sendKeys(ui);
	}
	
	public void set_Npass(String np) 
	{
		WebElement pd1=ut.waitforElement(new_pass,20);
		pd1.sendKeys(np);
	}
	
	public void set_Rpass(String rp) 
	{
		WebElement rd1=ut.waitforElement(re_pass,20);
		rd1.sendKeys(rp);
	}
	
	public void set_Fname(String fn) 
	{
		WebElement fn1=ut.waitforElement(f_name, 20) ;   
		fn1.sendKeys(fn);
	}
	
	
	public void set_Lname(String ln) 
	{
	WebElement ln1=ut.waitforElement(l_name, 20);
	ln1.sendKeys(ln);
	}
	
	public void set_email(String em) 
	{
		WebElement em1=ut.waitforElement(email, 20);
		em1.sendKeys(em);
		
	}
	
	public void set_phone(String pn) 
	{
		WebElement ph1=ut.waitforElement(phone, 20);
		ph1.sendKeys(pn);
	}
	
	public void set_add1(String add1) 
	{
		WebElement ad1=ut.waitforElement(add_1, 20);
		ad1.sendKeys(add1);
				}
	
	public void set_add2(String add2) 
	{
		WebElement ad2=ut.waitforElement(add_2, 20);
		ad2.sendKeys(add2);
	}
	
	public void set_city(String ci) 
	{
		WebElement ct=ut.waitforElement(city, 20);
		ct.sendKeys(ci);
	}
	
	public void set_state(String st) 
	{
		WebElement str=ut.waitforElement(state, 20);
		str.sendKeys(st);//dr.findElement(state).sendKeys(st);
	}
	
	public void set_zip(String zi) 
	{
		WebElement zp=ut.waitforElement(zip, 20);
		zp.sendKeys(zi);//dr.findElement(zip).sendKeys(zi);
	}
	
	public void set_country(String co) 
	{
		WebElement cy=ut.waitforElement(country, 20);
		cy.sendKeys(co);//dr.findElement(country).sendKeys(co);
	}
	

	public void lan_pre(String i)
	{
		
	WebElement web=dr.findElement(By.xpath("//div[@id='Catalog']//following::select"));
	Select se=new Select(web);
	se.selectByVisibleText(i);
	}
	
	

	public void fav_cat(String c)
	{
		
	
	WebElement web2=dr.findElement(By.xpath("//div[@id='Catalog']//following::select"));
	Select se2=new Select(web2);
	se2.selectByVisibleText(c);
	}
	
	public void clk_bt1() 
	{
		WebElement ml=ut.waitforElement(mylist, 20);
		ml.click();
	}
	
	
	public void clk_bt2() 
	{
		WebElement mb=ut.waitforElement(mybanner, 20);
		mb.click();
	}
	public void clk_save()
	{
		WebElement sa=ut.waitforElement(sve, 20);
		sa.click();
	}

	public void do_register(String ui, String np,String rp,String fn,String ln,String em,String pn,String add1 ,String add2,String ci,String st,String zi, String co,String web, String web2 )
	{
		this.set_userid(ui);
		this.set_Npass(np);
		this.set_Rpass(rp);
		
	this.set_Fname(fn);
		this.set_Lname(ln);
		this.set_email(em);
		this.set_phone(pn);
		this.set_add1(add1);
		this.set_add2(add2);
		this.set_city(ci);
		this.set_state(st);
		this.set_zip(zi);
		this.set_country(co);
		this.lan_pre(web);
		this.fav_cat(web2);
		this.clk_bt1();
		this.clk_bt2();
		this.clk_save();
		
	}
	public String get_title3()
	{
		return dr.getTitle();
	}
}

