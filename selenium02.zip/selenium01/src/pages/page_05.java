package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.DriverWait;

public class page_05 {
	WebDriver dr;
	DriverWait d;
	By name=By.xpath("//div[@id='Welcome']//following::span");
	
	public void page5(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public String verify()
	{
		 d=new DriverWait(dr);
		WebElement v=d.waitforElement(name,20);
		String na=v.getText();	
	return na;
	}
	
	
	public String get_title5()
	{
		return dr.getTitle();
	}
}
