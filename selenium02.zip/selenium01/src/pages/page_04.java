package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.DriverWait;

public class page_04 {
	WebDriver dr;
	DriverWait d;
	By username=By.xpath("//input[@name='username']");
	By password=By.xpath("//input[@name='password']");
	By log=By.xpath("//input[@id='login']");
	
	public void page4(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void username(String un)
	{
		d=new DriverWait(dr);
		WebElement uname=d.waitforElement(username,20);
		uname.sendKeys(un);
	}
	public void password(String pwod)
	{
		d=new DriverWait(dr);
		WebElement pw7=d.waitforElement(password,20);
		pw7.sendKeys(pwod);
	}
	
	public void login()
	{
		d=new DriverWait(dr);
		WebElement login=d.waitforElement(log,20);
	    login.click();
	}
	
	public void do_login(String u,String p)
	{
		this.username(u);
		this.password(p);
		this.login();
	}
	
	
	public String get_title4()
	{
		return dr.getTitle();
	}
}
