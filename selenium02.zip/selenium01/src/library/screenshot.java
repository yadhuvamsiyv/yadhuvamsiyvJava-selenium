package library;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class screenshot {
	WebDriver dr;
	static int i=0;
	
	public screenshot(WebDriver dr)
	{
		this.dr=dr;
	}
	public void ss()
	{
		File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2=new File ("C:\\Users\\BLTuser.BLT0202\\Desktop\\Newfolder\\ss["+i+"].png");
		try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			e.printStackTrace();
		}
		i++;
	}
}
