package library;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class page_01 {
	WebDriver dr;
	DriverWait d;
	By sign_in=By.xpath("//div[@id='Menu']//following::a[2]");
	
	public page_01(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void signin()
	{
		d=new DriverWait(dr);
		WebElement si=d.waitforElement(sign_in,20);
		si.click();
	}
	
	public String get_title1()
	{
		return dr.getTitle();
	}
}
