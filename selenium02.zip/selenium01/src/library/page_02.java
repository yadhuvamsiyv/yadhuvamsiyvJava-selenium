package library;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class page_02 {
	WebDriver dr;
	DriverWait d;
	By register=By.xpath("//div[@id='Content']//following::a[1]");
	public void page2(WebDriver dr)
	{
		this.dr=dr;
		}
	public void reg()
	{
		d=new DriverWait(dr);
		WebElement r=d.waitforElement(register,20);
		r.click();
	}
	public String get_title2()
	{
		return dr.getTitle();
	}
}

