package Tests;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Testchrome {
	WebDriver dr;
	screenshot s;
	@BeforeClass
	public void launchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("https://jpetstore.cfapps.io/catalog");
	}
	@Test(priority=1)
	public void test_page1() {
		page1 p1=new page1(dr);
		
		p1.signin();
		String get_title=p1.get_title1();
		Assert.assertTrue(get_title.contains("JPetStore Demo"));
		s=new screenshot(dr);
		s.ss();
}

	@Test(priority=2)
	public void test_page2() {
		page2 p2=new page2(dr);
		p2.reg();
		String get_title=p2.get_title2();
		Assert.assertTrue(get_title.contains("JPetStore Demo"));
		s.ss();
		
}
	@Test(priority=3)
	public void test_page3() {
		page3 p3=new page3(dr);
		p3.do_register();
		String get_title=p3.get_title3();
		Assert.assertTrue(get_title.contains("JPetStore Demo"));
		s.ss();
	}
	@Test(priority=4)
	public void test_page4() {
		page4 p4=new page4(dr);
		p4.do_login("","");
		
		
		String get_title=p4.get_title4();
		Assert.assertTrue(get_title.contains("JPetStore Demo"));
		s.ss();
	}
	@Test(priority=5)
	public void test_page5() {
		page5 p5=new page5(dr);
		p5.verify();
		
		s.ss();
		
}
	
	@AfterClass
		public void close()
		{
			dr.close();
		}
}
}
