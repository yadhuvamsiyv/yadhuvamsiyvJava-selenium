package Tests;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


import junit.framework.Assert;
import library.page_01;
import library.page_02;
import library.screenshot;
import pages.page_03;
import pages.page_04;
import pages.page_05;

public class Testfirefox {
	WebDriver dr;
	screenshot s;
	@BeforeClass
	public void launchBrowser()
	{
		System.setProperty("webdriver.gecko.driver","geckodriver.exe");
		dr=new FirefoxDriver();
		dr.get("https://jpetstore.cfapps.io/catalog");
	}
	
	@Test(priority=1)
	public void test_page1() {
		page_01 p1=new page_01(dr);
		
		p1.signin();
		String get_title=p1.get_title1();
		Assert.assertTrue(get_title.contains("JPetStore Demo"));
		s=new screenshot(dr);
		s.ss();
}

	@Test(priority=2)
	public void test_page2() {
		page_02 p2=new page_02(dr);
		p2.reg();
		String get_title=p2.get_title2();
		Assert.assertTrue(get_title.contains("JPetStore Demo"));
		s.ss();
		
}
	@Test(priority=3)
	public void test_page3() {
		page_03 p3=new page_03(dr);
		p3.do_register("ra012345ab","ramyarams11","ramyarams11","swargam","ramya","swarga.rama1abcd@gmail.com","8142124326","thilak nagar","kadapa","kadapa","andhra pradesh","516003","india","English","DOGS");
		String get_title=p3.get_title3();
		Assert.assertTrue(get_title.contains("JPetStore Demo"));
		s.ss();
	}
	@Test(priority=4)
	public void test_page4() {
		page_04 p4=new page_04(dr);
		p4.do_login();
		
		
		String get_title=p4.get_title4();
		Assert.assertTrue(get_title.contains("JPetStore Demo"));
		s.ss();
	}
	@Test(priority=5)
	public void test_page5() {
		page_05 p5=new page_05(dr);
		p5.verify();

		
}
	
	@AfterClass
		public void close()
		{
			dr.close();
		}
}
