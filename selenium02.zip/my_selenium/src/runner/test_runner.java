package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="Features",glue="STEP_DEF")

public class test_runner extends AbstractTestNGCucumberTests {

}
