package STEP_DEF;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test_1 {
WebDriver dr;
//String m="100vamsi100@gmail.com";
	@Given("^Browser is launched & login page dispalyed$")
	public void browser_is_launched_login_page_dispalyed() throws Throwable {
	   System.out.println("Browser is launched & login page dispalyed");
	   System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	 dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("//a[@class='ico-login']")).click();
	}

	@When("^User enters login credentials &click on login$")
	public void user_enters_login_credentials_click_on_login() throws Throwable {
	   //System.out.println("User enters login credentials &click on login");
	   dr.findElement(By.xpath("//input[@class='email']")).sendKeys("100vamsi100@gmail.com");
		dr.findElement(By.xpath("//input[@class='password']")).sendKeys("vanitha143");
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
}

	@Then("^successful login happens & profile name displayed correctly$")
	public void successful_login_happens_profile_name_displayed_correctly() throws Throwable {
	   System.out.println("successful login happens & profile name displayed correctly");
	   String s1=dr.findElement(By.xpath("//a[@class='account']")).getText();
	   if(s1.equals("100vamsi100@gmail.com")) {
		   System.out.println("pass");
	   }
	   else {
		   System.out.println("fail");
	   }
	}

}
