package runner_pkg;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="Feature",glue="STEP_DEF")
public class test_runner extends AbstractTestNGCucumberTests {

}
