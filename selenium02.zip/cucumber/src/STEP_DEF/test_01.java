package STEP_DEF;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test_01 {
	@Given("^Browser is launched & login page dispalyed$")
	public void browser_is_launched_login_page_dispalyed() throws Throwable {
	   
	}

	@When("^User select option and click search$")
	public void user_select_option_and_click_search() throws Throwable {
	    
	}

	@Then("^verifying both title of the next page and second book name$")
	public void verifying_both_title_of_the_next_page_and_second_book_name() throws Throwable {
	   
	}

}
