package utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriveBrowser_ch {
	static WebDriver dr;


	public static WebDriver Launch_browser(String browser,String url)
	{

	switch(browser)
	{
	case "CHROME":
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr=new ChromeDriver();
	break;
	case "FIREFOX":
	System.setProperty("webdriver.gecko.driver","geckodriver.exe");
	dr=new FirefoxDriver();
	break;

	}

	dr.get(url);


	return dr;
	}

	
}
