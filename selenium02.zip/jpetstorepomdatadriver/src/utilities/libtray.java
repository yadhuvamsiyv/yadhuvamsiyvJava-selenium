package utilities;

import java.io.File;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class libtray {
	static int counter=1;
	 WebDriver dr;
	static Logger log;
	

	public libtray(WebDriver dr)
	{

	this.dr=dr;
	log=Logger.getLogger("devpinoyLogger");
	}
	public void update_log(String msg) {
		log.debug(msg);
	}
	
	public WebElement waitforElements(By locator,int timeout)
	{

	
	try {

	WebDriverWait wait=new WebDriverWait(dr, timeout);
	           
	WebElement element= wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	           return element;
	}
	catch(Exception e)
	{
	System.out.println("no found element");
	return null;
	}
	}
	public WebElement waitToClickable(By locator,int timeout)
	{
	try {

	WebDriverWait wait=new WebDriverWait(dr, timeout);
	           
	WebElement element= wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	           return element;
	}
	catch(Exception e)
	{
	return null;
	}
	}
	
}
