package TestNGBook;





import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pages.Loginpage;
import excelread.REadrow;
import utilities.DriveBrowser_ch;
import utilities.libtray;


  
  
  public class jpetstestNg_1 extends REadrow {

	  static WebDriver dr;
	  libtray util;

	  String RM="Your account has been created. Please try login !!";
	  @BeforeClass
	  public void launchBrowser()
	  {

	  getdata();
	  util=new libtray(dr);
	   util.update_log("completed reading from excel");
	  // String url="https://jpetstore.cfapps.io/login";
	  //  Ar= Utilites.DriveBrowser.Launch_browser("FIREFOX", url);
	  }
	   
	    @Test(dataProvider="logindata")
	    public void Login(String username,String pwd)
	    {
	   System.out.println(username+" "+pwd );
	   String url="https://jpetstore.cfapps.io/login";
	        dr= DriveBrowser_ch.Launch_browser("FIREFOX", url);
	   Loginpage L=new Loginpage(dr);
	   L.loginstart(username,pwd);
	   dr.close();
	     
	    }
	   
	   
	    @DataProvider(name="logindata")
	    public String[][] Provide_data()
	    {
	   return testdata;
	    }
}
