package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

public class test_AUT_login {
	 
WebDriver dr;
AUT_login_page loginpage;
AUT_home_page homepage;

@BeforeClass
public void launchBrowser()
{
System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
 dr=new ChromeDriver();
dr.get("http://demowebshop.tricentis.com/login");
}

@Test(priority=0)
  public void test_login_page() {
loginpage=new AUT_login_page(dr);
String login_page_title=loginpage.get_title();
Assert.assertTrue(login_page_title.contains("Shop"));
  }

@Test(priority=2)
 public void test_home_page() {
loginpage.do_login("100vamsi100@gmail.com","vanitha143");
homepage=new AUT_home_page(dr);
String actual_eid=homepage.get_dispalyed_eid();
Assert.assertTrue(actual_eid.contains("100vamsi100@gmail.com"));
 }
}