package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class login_testNG 
{
	WebDriver dr;
	login_page loginpage;
	home_page homepage;
	
	
	@BeforeClass
	public void Lan_browser()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		 dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
	}
  @Test
  public void test_home_page() {
	  
	  
	  
	  loginpage=new login_page(dr);
	  
	  String match_title=loginpage.get_title();
	  System.out.println(match_title);
	  
	  
//Assert.assertTrue(match_title.contains("Swag labs"));
	  
	  loginpage.do_login("standard_user","secret_sauce");
	  
	  homepage=new home_page(dr);
	  
	  String actual_title=homepage.verify_title();
	  Assert.assertTrue(actual_title.contains("Products"));
	  
	  String actual_pn=homepage.verify_pn();
	  System.out.println(actual_pn);
	  Assert.assertTrue(actual_pn.contains("Sauce Labs Backpack"));
	  
  }
}
