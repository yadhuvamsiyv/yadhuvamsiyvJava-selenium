package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class login_page {
	WebDriver dr;
	 
	
	 @FindBy(xpath="//input[@type='text']")
	 WebElement UR;
	 @FindBy(xpath="//input[@type='password']")
	 WebElement PWD;
	 @FindBy(xpath="//input[@type='submit']")
	 WebElement LGN;

	 
	 public login_page(WebDriver dr)
	 {
		 this.dr=dr;
		 PageFactory.initElements(dr, this);
	 }
	 public void Set_Username(String Username){
		 UR.sendKeys(Username);
	 }
	 public void Set_Password(String Password){
		 PWD.sendKeys(Password);
	 }
	 public void Clicklogin(){
		 LGN.click();
	 }
	 public void do_login(String U,String P){
		 this.Set_Username(U);
		 this.Set_Password(P);
		 this.Clicklogin();
	 }
	 
	 public String get_title(){
		 return dr.getTitle();
		 
	 }

	
}
