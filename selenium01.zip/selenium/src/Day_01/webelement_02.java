package Day_01;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelement_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
WebDriver dr = new ChromeDriver();
dr.get("http://demowebshop.tricentis.com");


dr.findElement(By.linkText("Log in")).click();
dr.findElement(By.id("Email")).sendKeys("100vamsi100@gmail.com");
dr.findElement(By.id("Password")).sendKeys("vanitha143");
dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();



String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
System.out.println(s);
String str="100vamsi100@gmail.com";
if(str.compareTo(s)==0)

	{
	System.out.println("pass");
	
	}
else
{
	System.out.println("fail");
}
	
	}

}
