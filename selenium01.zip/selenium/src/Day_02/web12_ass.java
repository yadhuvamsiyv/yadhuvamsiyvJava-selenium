package Day_02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class web12_ass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		dr.findElement(By.xpath("//input[@name='user_login']")).sendKeys("100vamsi100");
		dr.findElement(By.xpath("//input[@name='user_password']")).sendKeys("vanitha143");
		dr.findElement(By.xpath("//input[@name='first_name']")).sendKeys("yadhu");
		dr.findElement(By.xpath("//input[@name='last_name']")).sendKeys("vamsi");
		dr.findElement(By.xpath("//input[@name='email']")).sendKeys("100vamsi100@gmail.com");
		dr.findElement(By.xpath("//input[@name='address1']")).sendKeys("d.no:31-2-17");
		dr.findElement(By.xpath("//input[@name='address2']")).sendKeys("nakka vari street");
		dr.findElement(By.xpath("//input[@name='address3']")).sendKeys("velpur road");
		dr.findElement(By.xpath("//input[@name='city']")).sendKeys("Tanuku");
		
		WebElement wb=dr.findElement(By.xpath("//select[@name='state_id']"));                  
		Select DD=new Select(wb);
		DD.selectByVisibleText("New York");
		
		dr.findElement(By.xpath("//input[@name='zip']")).sendKeys("53421");
		
		WebElement wb1=dr.findElement(By.xpath("//select[@name='country_id']"));                  
		Select DD1=new Select(wb1);
		DD1.selectByVisibleText("India");
		
		dr.findElement(By.xpath("//input[@name='phone_home']")).sendKeys("8331848477");
		dr.findElement(By.xpath("//input[@name='phone_work']")).sendKeys("9959859663");
		
		WebElement wb2=dr.findElement(By.xpath("//select[@name='language_id']"));                   
		Select DD2=new Select(wb2);
		DD2.selectByVisibleText("English");
		
		WebElement wb3=dr.findElement(By.xpath("//select[@name='age_id']"));                   
		Select DD3=new Select(wb3);
		DD3.selectByVisibleText("25-34");
		
		WebElement wb4=dr.findElement(By.xpath("//select[@name='gender_id']"));                   
		Select DD4=new Select(wb4);
		DD4.selectByVisibleText("Male");
		
		WebElement wb5=dr.findElement(By.xpath("//select[@name='education_id']"));                   
		Select DD5=new Select(wb5);
		DD5.selectByVisibleText("College");
		
	    WebElement wb6=dr.findElement(By.xpath("//select[@name='income_id']"));                   
	    Select DD6=new Select(wb6);
	    DD6.selectByVisibleText("$25,000 - $34,000");
	
		dr.findElement(By.xpath("//textarea[@name='note']")).sendKeys("i am hero");
	
		dr.findElement(By.xpath("//input[@name='Insert']")).click();
		
		dr.findElement(By.xpath("//img[@src='images/home.gif']")).click();
		
		String s1="100vamsi100";
		dr.findElement(By.xpath("//input[@name='s_keyword']")).sendKeys(s1);
		
		dr.findElement(By.xpath("//input[@type='image']")).click();
		
		String s2=dr.findElement(By.xpath("//a[@href='RegistrationView.php?s_keyword=100vamsi100&user_id=3']")).getText();
		
		if(s2.compareTo(s1)==0)
		{
			System.out.println("submission is success");
		}
		else
		{
			System.out.println("submission is not success");
		}
	}
}
