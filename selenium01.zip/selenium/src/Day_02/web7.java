package Day_02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class web7 {
	

		
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String username="100vamsi100@gmail.com";
		String password="";
		
		
		String ex_er="Login was unsuccessful. Please correct the errors and try again.The credentials provided are incorrect";
		
		
		dr.findElement(By.xpath("//a[@class='ico-login']")).click();
		
		dr.findElement(By.xpath("//input[@class='email']")).sendKeys(username);
		dr.findElement(By.xpath("//input[@class='password']")).sendKeys(password);
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		String ac_er=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		String ac_er1=dr.findElement(By.xpath("//div[@class='message-error']//child::li")).getText();
		String ac_er2=ac_er.concat(ac_er1);
		System.out.println(ac_er2);
		if(ac_er2.equals(ex_er))
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
	}
	

}
