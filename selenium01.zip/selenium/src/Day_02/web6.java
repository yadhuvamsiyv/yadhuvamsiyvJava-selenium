package Day_02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class web6 {
	public String login(String st1,String st2)
	{

	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");

	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	
	
	dr.findElement(By.xpath("//a[@class='ico-login']")).click();
    dr.findElement(By.xpath("//input[@class='email']")).sendKeys(st1);
	   dr.findElement(By.xpath("//input[@class='password']")).sendKeys(st2);
	   dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	  
	   String ex_e;
	  if(st1.contains("@gmail.com")==true) 
	  {
		  ex_e=dr.findElement(By.xpath("//div[@class='header-links']//following::a")).getText();
		  if(ex_e.equals("Register"))
			  ex_e=dr.findElement(By.xpath("//div[@calss='validations-summary-errors']")).getText();
	  }
	  else{
		  ex_e=dr.findElement(By.xpath("//span[@class='field-validation-error']//child::span")).getText();
	  }
	  dr.close();
	  dr.quit();
	return ex_e;
	}
	
	
	public String readxl(String filename,String Sheet,int r,int c)
	{
	String s=null;
	try {
	File f=new File(filename);
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb =new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet(Sheet);
	XSSFRow row=sh.getRow(r);
	XSSFCell cell =row.getCell(c);
	s=cell.getStringCellValue();
	}
	catch (FileNotFoundException e) 
	{
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	catch (IOException e) 
	{
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	return s;
	}

	public void writexl(String filename,String Sheet1,int r,int c,String data){
		try {
			File f=new File(filename);
			FileInputStream fin= new FileInputStream(f);
			XSSFWorkbook wb =new XSSFWorkbook(fin);
			XSSFSheet sh= wb.getSheet(Sheet1);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.createCell(c);
			XSSFCell cell1=row.getCell(c);
			
		cell1.setCellValue(data);
		FileOutputStream fos =new FileOutputStream(f);
		wb.write(fos);
		}
		catch (FileNotFoundException e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		catch (IOException e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
				
			
	}

	public static void main(String[] args) {
	
		
web6 f1=new web6();
		for(int r=1;r<=4;r++)
		{
		String a=f1.readxl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", r, 0);
		String a1=f1.readxl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", r, 1);
		String a3=f1.readxl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", r, 2);
		String a2=f1.login(a, a1);
		f1.writexl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", r,3,a2);
String s1;
if(a3.compareTo(a2)==0)
{
	s1="pass";
}
else
{
	s1="fail";
}
f1.writexl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", r,4,s1);

	}

}
}
