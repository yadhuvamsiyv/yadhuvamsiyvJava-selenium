package Day_02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class web11_ass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String s1=dr.getTitle();
		System.out.println(s1);
		
		
		WebElement wb=dr.findElement(By.xpath("//select[@name='category_id']"));
		Select DD=new Select(wb);
		DD.selectByVisibleText("Databases");
		
		
		dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
		dr.findElement(By.xpath("//a[@href='ProductDetail.php?product_id=1']")).click();
		
		
		String name= dr.findElement(By.xpath("//td[@valign='top'][1]//child::h1")).getText();
		System.out.println(name);
		
		
		String price=dr.findElement(By.xpath("//td[@colspan='2']")).getText();
		System.out.println(price);
		
	
		dr.findElement(By.xpath("//input[@value='1']")).clear();
		String value="2";                                                                
		dr.findElement(By.xpath("//input[@value='1']")).sendKeys(value);
		
		
		dr.findElement(By.xpath("//input[@name='Insert1']")).click();              
		
		
		String total=dr.findElement(By.xpath("//td[@align='right'][3]")).getText();
		System.out.println("total : " + total);
		
		
		double p1,p2;
		p1=Double.parseDouble(price.substring(8,13))*2;
		p2=Double.parseDouble(total.substring(1,6));
		if(p1==p2)
		{
			System.out.println("matched");
		}
		else
		{
			System.out.println("not matched");
		}
	}

}
