package Day_02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class web8 {
	String s1,AC_err3,s2;
	public String login(String Username,String Password)
	{
	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");  
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	dr.findElement(By.xpath("//a[@class='ico-login']")).click();
	dr.findElement(By.xpath("//input[@class='email']")).sendKeys(Username);
	dr.findElement(By.xpath("//input[@class='password']")).sendKeys(Password);
	dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	s1=dr.findElement(By.xpath("//a[@class='account']")).getText();
	// System.out.println(s1);  Username.compareTo(s1)==0 Login was unsuccessful. Please correct the errors and try again.The credentials provided are incorrect
	if(Username.contains("@gmail.com"))
	{
	if( Username.compareTo(s1)==0)
	{
	dr.close();
	return s1;
	}
	else
	{
	String AC_err1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
	String AC_err2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
	AC_err3=AC_err1.concat(AC_err2);
	dr.close();
	return AC_err3;

	}
	}
	else
	{
	String s3=s1=dr.findElement(By.xpath("//span[@for='Email']")).getText();
	dr.close();
	return s3;
	}

	}


	public String readexcel(String filename,String Sheet,int r,int c)
	{
	String s=null;
	try {
	File f=new File(filename);
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet(Sheet);
	XSSFRow row=sh.getRow(r);
	XSSFCell cell =row.getCell(c);
	s=cell.getStringCellValue();
	} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	return s;
	}

	public void writeexcel(String filename,String Sheet1,int r,int c,String data)
	{
	try {
	File f=new File(filename);
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet(Sheet1);
	XSSFRow row=sh.getRow(r);
	XSSFCell cell=row.createCell(c);
	XSSFCell cell1=row.getCell(c);
	cell1.setCellValue(data);
	FileOutputStream fos=new FileOutputStream(f);
	wb.write(fos);

	} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		web8 f1=new web8();
		// int r=1;
		for(int r=1;r<=5;r++)
		{
		String d=f1.readexcel("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\data.xlsx","Sheet1", r, 0);
		String d1=f1.readexcel("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\data.xlsx","Sheet1", r, 1);
		String d3=f1.readexcel("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\data.xlsx","Sheet1", r, 2);
		String d2=f1.login(d, d1);
		f1.writeexcel("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\data.xlsx","Sheet1",r,3,d2);
		String s1;
		if(d3.compareTo(d2)==0)
		{
		s1="pass";
		}
		else
		{
		s1="fail";
		}
		f1.writeexcel("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\data.xlsx","Sheet1",r,4,s1);

		}
	}

}
