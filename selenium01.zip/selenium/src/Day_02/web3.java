package Day_02;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class web3 {
	public void login(String str1,String str2)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.xpath("//a[@class='ico-login']")).click();
		dr.findElement(By.xpath("//input[@class='email']")).sendKeys(str1);
		dr.findElement(By.xpath("//input[@class='password']")).sendKeys(str2);
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	
	
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		web3 f1=new web3();
		f1.login("100vamsi100@gmail.com","vanitha143");

	}

}
