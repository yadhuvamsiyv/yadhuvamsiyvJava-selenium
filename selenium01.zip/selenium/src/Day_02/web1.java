package Day_02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class web1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		
		
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/accessories");
		int a=2;
		
		
		dr.findElement(By.xpath("//div[@class='item-box']["+a+"]//child::input")).click();
		
		dr.findElement(By.xpath("//span[@class='cart-label']")).click();
		
		//dr.findElement(By.xpath("//td[@class='remove-from-cart']//child::input")).click();
		//dr.findElement(By.xpath("//div[@class='common-buttons']//child::input")).click();
	
	
	dr.findElement(By.xpath("//td[@class='qty nobr']//child::input")).clear();
	dr.findElement(By.xpath("//td[@class='qty nobr']//child::input")).sendKeys("2");
	
	
	//System.out.println(L.getAttribute("value"));
	
	dr.findElement(By.xpath("//div[@class='common-buttons']//child::input")).click();
	
	}

}
