package Day_02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class logic_ass1 {
WebDriver dr;

public void logic1(WebDriver dr, String userName, String password) {
	// TODO Auto-generated method stub
	dr.findElement(By.xpath("//input[@class='form_input']")).sendKeys(userName);
	dr.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
	dr.findElement(By.xpath("//input[@type='submit']")).click();
	
}
public logic_ass1(WebDriver dr){
	this.dr=dr;
}

}
