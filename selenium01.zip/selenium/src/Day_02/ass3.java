package Day_02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ass3 {
	WebDriver dr;
	String name;
	String price;
	String price1;
	public ass3(WebDriver dr)
	{
	this.dr=dr;
	}


	public void launch(){
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr = new ChromeDriver();
	dr.get("https://www.saucedemo.com");
	}

	public void login(String str1,String str2)
	{
	dr.findElement(By.xpath("//input[@id='user-name']")).sendKeys(str1);
	dr.findElement(By.xpath("//input[@id='password']")).sendKeys(str2);
	dr.findElement(By.xpath("//input[@type='submit']")).click();
	}

	public void add_product(int n){
	name=dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::div[@class='inventory_item_name'][1]")).getText();
	price=dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::div[@class='inventory_item_price'][1]")).getText();
	dr.findElement(By.xpath("//div[@class='inventory_item']["+n+"]//child::button[@class='btn_primary btn_inventory']")).click();
	dr.findElement(By.xpath("//a[@href='./cart.html']")).click();
	}

	public void verify(){
	String s1=dr.findElement(By.xpath("//div[@class='inventory_item_name']")).getText();
	String s2=dr.findElement(By.xpath("//div[@class='item_pricebar']//child::div[@class='inventory_item_price']")).getText();
	price1=price.substring(1);
	if(s1.equals(name) && s2.equals(price1))
	{
	System.out.println("pass");
	}
	else{
	System.out.println("fail");
	}
	}
	public void shopping(){
	dr.findElement(By.xpath("//a[@class='btn_secondary']")).click();
	}
}
