package Day_02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class web5 {
	public String login(String st1,String st2)
	{

	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");

	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	dr.findElement(By.xpath("//a[@class='ico-login']")).click();

	   dr.findElement(By.xpath("//input[@class='email']")).sendKeys(st1);
	   dr.findElement(By.xpath("//input[@class='password']")).sendKeys(st2);
	   dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	   String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	return s1;
	}
	
	
	public String readxl(String filename,String Sheet,int r,int c)
	{
	String s=null;
	try {
	File f=new File(filename);
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb =new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet(Sheet);
	XSSFRow row=sh.getRow(r);
	XSSFCell cell =row.getCell(c);
	s=cell.getStringCellValue();
	}
	catch (FileNotFoundException e) 
	{
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	catch (IOException e) 
	{
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	return s;
	}

	public void writexl(String filename,String Sheet1,int r,int c,String data){
		try {
			File f=new File(filename);
			FileInputStream fin= new FileInputStream(f);
			XSSFWorkbook wb =new XSSFWorkbook(fin);
			XSSFSheet sh= wb.getSheet(Sheet1);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.createCell(c);
			XSSFCell cell1=row.getCell(c);
			
		cell1.setCellValue(data);
		FileOutputStream fos =new FileOutputStream(f);
		wb.write(fos);
		}
		catch (FileNotFoundException e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		catch (IOException e) 
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
				
			
	}
	
	public static void main(String[] args) {
		
		
		web5 f1=new web5();
		
		String a=f1.readxl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", 1, 0);
		String a1=f1.readxl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", 1, 1);
		String a3=f1.readxl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", 1, 2);
		String a2=f1.login(a, a1);
		System.out.println(a2);
		f1.writexl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", 1,3,a2);
String s1;
if(a3.compareTo(a2)==0)
{
	s1="pass";
}
else
{
	s1="fail";
}
f1.writexl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", 1,4,s1);
	}

}
