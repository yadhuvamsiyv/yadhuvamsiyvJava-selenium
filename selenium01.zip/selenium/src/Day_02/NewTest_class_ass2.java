package Day_02;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest_class_ass2 {
	@BeforeClass
	 public void B1() {
		  System.out.println("Before class");
	  }
	 @BeforeMethod
	  public void f1() {
		  System.out.println("test result 1");
	  }
	  @Test
	  public void f2() {
		  System.out.println("test result 2");
	  }
	  @Test
	  public void f3() {
		  System.out.println("test result 3");
	  }
	  @AfterClass
		  public void B2() {
			  System.out.println("After class");
		  }
}

