package Day_02;

import java.io.File;



import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class web10_ss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Username="100vamsi100@gnmail.com", Password="vanitha143";
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//a[@class='ico-login']")).click();
		dr.findElement(By.xpath("//input[@class='email']")).sendKeys(Username);
		dr.findElement(By.xpath("//input[@class='password']")).sendKeys(Password);
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		String s1=dr.findElement(By.xpath("//a[@class='account']")).getText();
		
		File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2=new File("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\ss1.png");
	try {
		FileUtils.copyFile(f1,f2);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}
