package Day_02;

public class webelement_044 {
	public String extract()
	{
		String p1=indexof(":",0);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	}

}
public void AddCart()
{
//	dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
//	String Name1=dr.findElement(By.xpath("//div[@class='inventory_item_name'][1]")).getText();
//	String Price1=dr.findElement(By.xpath("//div[@class='inventory_item_price'][1]")).getText();
//	System.out.println(Name1);
//	System.out.println(Price1);
}
