package Day_02;

import org.testng.annotations.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;


public class Test_NG_ass1
{
WebDriver dr;
logic_ass1 L1;

@BeforeMethod
public void BM(){
System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
dr=new ChromeDriver();
dr.get("https://www.saucedemo.com/");
L1=new logic_ass1(dr);
}
@Test
public void f1(){
	L1.logic1(dr, "standard_user", "secret_sauce");
}
@Test
public void f2(){
	L1.logic1(dr,"problem_user","secret_sauce");
}
@AfterMethod
public void AM(){
	dr.close();
}
}
