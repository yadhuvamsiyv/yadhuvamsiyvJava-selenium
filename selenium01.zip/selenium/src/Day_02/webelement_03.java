package Day_02;





import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class webelement_03 {
	static String str;
	public static void extract()
	{
	
		int p1=str.indexOf(":",1);
		int p=str.indexOf("A",1);
		String s= str.substring(p1+2,p-1);
		System.out.println(s);
		
		
	}

	

	public static void main(String[] args) {
		webelement_03 n=new webelement_03();
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
		
	/*List rb=dr.findElements(By.name("optradio"));
	((WebElement)rb.get(0)).click();
*/
		/*List rb=dr.findElements(By.name("optradio"));
	((WebElement)rb.get(0)).click();*/
		
		
	/*	WebElement we=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select"));
Select sel= new Select(we);
sel.selectByVisibleText("Databases");*/
		
		List rb=dr.findElements(By.name("gender"));
		((WebElement)rb.get(0)).click();
		
		List rb1=dr.findElements(By.name("ageGroup"));
		((WebElement)rb1.get(0)).click();
		dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/button")).click();
	n.str=dr.findElement(By.xpath("//*[@id='easycont']/div/div[2]/div[2]/div[2]/p[2]")).getText();
	System.out.println(str);
	n.extract();
	}

}
