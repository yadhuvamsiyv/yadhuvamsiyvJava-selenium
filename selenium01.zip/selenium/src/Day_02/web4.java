package Day_02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class web4 {
	
	
	public void login(String st1,String st2)
	{

	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");

	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	dr.findElement(By.xpath("//a[@class='ico-login']")).click();

	   dr.findElement(By.xpath("//input[@class='email']")).sendKeys(st1);
	   dr.findElement(By.xpath("//input[@class='password']")).sendKeys(st2);
	   dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	}
	
	
	public String readxl(String filename,String Sheet,int r,int c)
	{
	String s=null;
	try {
	File f=new File(filename);
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb =new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet(Sheet);
	XSSFRow row=sh.getRow(r);
	XSSFCell cell =row.getCell(c);
	s=cell.getStringCellValue();
	}
	catch (FileNotFoundException e) 
	{
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	catch (IOException e) 
	{
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	return s;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		web4 f1=new web4();
		String a=f1.readxl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", 0, 0);
		String a1=f1.readxl("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\my.xlsx","details", 0, 1);
		f1.login(a, a1);


		}


	}


