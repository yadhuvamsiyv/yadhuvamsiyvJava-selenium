package Day_02;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ass3TestNG {
	WebDriver dr;
	ass3 tg;
	int n;

	@BeforeClass
	public void b(){
	tg=new ass3(dr);
	tg.launch();
	tg.login("standard_user", "secret_sauce");
	}

	@BeforeMethod
	public void bm(){
	tg.add_product(3);
	}
	  @Test
	  public void f() {
	 tg.verify();  
	  }
	 
}
