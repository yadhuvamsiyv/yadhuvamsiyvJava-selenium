package Day_02;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class web9 {
	public void login(String str1,String str2)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		//dr.findElement(By.xpath("//a[@class='ico-login']")).click();
		//dr.findElement(By.xpath("//input[@class='email']")).sendKeys(str1);
		//dr.findElement(By.xpath("//input[@class='password']")).sendKeys(str2);
		//dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	try{
		WebDriverWait wt= new WebDriverWait(dr,20);
		WebElement we= wt.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Log in")));
		
		try{
			dr.findElement(By.linkText("Log in1")).click();
		}
		catch(WebDriverException e){
			System.out.println("an exceptional case");
		}
	}
	catch(TimeoutException e){
		System.out.println("WebDriver couldn't locate the element");
	}
	System.out.println("WebDriver execution continues");
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		web9 f1=new web9();
		f1.login("100vamsi100@gmail.com","vanitha143");
	}

}
