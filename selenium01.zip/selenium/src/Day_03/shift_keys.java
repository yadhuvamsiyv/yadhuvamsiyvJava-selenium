package Day_03;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class shift_keys {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
WebDriver dr=new ChromeDriver();
dr.get("http://demowebshop.tricentis.com");
dr.findElement(By.xpath("//a[@class='ico-login']")).click();

WebElement email=dr.findElement(By.xpath("//input[@class='email']"));
email.sendKeys("yadhuvamsi");
Actions kbm= new Actions (dr);
kbm
.keyDown(email,Keys.SHIFT)
.sendKeys(email,"yadhuvamsi")
.keyUp(email,Keys.SHIFT)
.build()
.perform();
	}

}
