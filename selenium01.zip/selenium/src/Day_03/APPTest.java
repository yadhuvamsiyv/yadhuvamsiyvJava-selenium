package Day_03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class APPTest {
 String e_name=null,e_price=null,a_name=null,a_price=null;
	WebDriver dr;
	SoftAssert sa=new SoftAssert();
	int a[]={1,6};
	int i=0;
	ass3 L;

	@BeforeClass
	 public void beforeClass() {
	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	dr=new ChromeDriver();
	dr.get("http://www.saucedemo.com");
	L=new ass3(dr);
	L.login("standard_user","secret_sauce");
	}

	@BeforeMethod

	 public void beforeMethod()
	{
	L.addproduct(a[i]);
	}

	@Test
	  public void f3()
	{
      a_name = dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][1]")).getText();
      a_price = dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][1]")).getText();

      sa.assertEquals(L.e_name, a_name);
      sa.assertAll();
	}

	@Test
	 public void f4()
	{
		a_name = dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][2]")).getText();
		a_price = dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][2]")).getText();
		
		sa.assertEquals(L.e_price.substring(1),a_name);
		sa.assertAll();
	}
	
	@AfterMethod
	public void aftermethod()
	{
	if(i<1)
	{
	dr.findElement(By.xpath("//div[@class='cart_footer']//child::a")).click();
	}
	else
	{
	dr.findElement(By.xpath("//div[@class='cart_footer']//child::a[2]")).click();
	}
	i++;
	}
	@AfterClass
	public void afterClass()
	{
	System.out.println("in AC");
	L.info();
	}
}
