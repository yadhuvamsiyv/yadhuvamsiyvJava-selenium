package Day_03;

public class get_test_data_xl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int c;
String s=null,s1=null,s2=null;
try{
	
}
	}

}
