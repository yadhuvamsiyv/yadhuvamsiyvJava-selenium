package Day_03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ass3 {
	WebDriver dr;
	String e_name;
	String e_price;
	String a_name;
	String a_price;

	public void login(String username,String password)
	{
	dr.findElement(By.xpath("//input[@type='text']")).sendKeys(username);
	dr.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
	dr.findElement(By.xpath("//input[@type='submit']")).click();
	}
	public ass3(WebDriver dr)
	{
	this.dr=dr;
	}
	public void addproduct(int n)
	{
	e_name = dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name']["+n+"]")).getText();//name of item
	e_price = dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price']["+n+"]")).getText();//price of item
	dr.findElement(By.xpath("//div[@class='inventory_item_price']//following::button["+n+"]")).click();     //add to cart
	dr.findElement(By.xpath("//div[@class='shopping_cart_container']//child::a[1]")).click();
	}
	public void verify(int n)
	{
	//click on shopping cart
	a_name = dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name']["+n+"]")).getText();//actual name of item
	a_price = dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price']["+n+"]")).getText();//actual price of item
	System.out.println(e_name);
	System.out.println(e_price);
	System.out.println(a_name);
	System.out.println(a_price);
	if(e_name.equals(a_name))
	{
	System.out.println("name matched");
	}
	else
	{
	System.out.println("name not matched");
	}

	if(a_price.equals(e_price.substring(1)))
	{
	System.out.println("price matched");
	}
	else
	{
	System.out.println("price not matched");
	}

	}
	public void info()
	{

	dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[1]")).sendKeys("Yadhu");
	dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[2]")).sendKeys("Vamsi");
	dr.findElement(By.xpath("//div[@class='checkout_info']//child::input[3]")).sendKeys("600042");
	dr.findElement(By.xpath("//div[@class='checkout_buttons']//following::input[1]")).click();
	dr.findElement(By.xpath("//div[@class='cart_footer']//child::a[2]")).click();
	}
}
