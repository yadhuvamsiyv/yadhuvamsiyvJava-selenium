package Day_03;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

public class NewTestPriority {
	 @Test(priority=1)
	  public void f2() {
		  System.out.println("test result 2");
	  }
	  @Test(priority=3)
	  public void f3() {
		  System.out.println("test result 3");
	  }
	  @Test(priority=2)
		  public void f4() {
			  System.out.println("test result 1");
		  }
}
