package Day_03;

import org.testng.annotations.Test;

public class DataProvider_xl {
  @Test
  public void f() {
  }
}
