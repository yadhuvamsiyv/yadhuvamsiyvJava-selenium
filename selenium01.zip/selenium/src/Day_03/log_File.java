package Day_03;

import org.apache.log4j.Logger;

public class log_File {

	public static void main(String[] args) {
		
		System.out.println("hgfhjs");
		Logger log=Logger.getLogger("devpinoyLogger");
		log.debug("Error happened");
		log.info("info msg");
			}
	}


