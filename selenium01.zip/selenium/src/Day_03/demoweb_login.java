package Day_03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demoweb_login {

	String l1;


public String logindemo(String username,String password){
	
	
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");


		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys(username);
		dr.findElement(By.id("Password")).sendKeys(password);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		l1=dr.findElement(By.xpath("//a[@class='account']")).getText();
return l1;		
}
	

}
