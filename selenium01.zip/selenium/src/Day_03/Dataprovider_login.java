package Day_03;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Dataprovider_login {
	
	demoweb_login k1;
	
	 @Test(dataProvider="dp")
	  public void login(String username, String password, String exp_result) 
	  {
		 String Ac_result;
		 k1=new demoweb_login();
		  Ac_result=k1.logindemo(username, password);
		 System.out.println(Ac_result);
		 SoftAssert sa=new SoftAssert();
		 sa.assertEquals(Ac_result, exp_result);
		 sa.assertAll();
	  }
	 
	 
	 @DataProvider(name="dp")
	  public String[][] provide_data()
	  {
		  String[][] data={
				  {"100vamsi100@gmail.com","vanitha143","100vamsi100@gmail.com"}
		  };
		  return data;
  }
}
