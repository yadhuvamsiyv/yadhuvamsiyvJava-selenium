package Day_04;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class all_webelement_fns {
WebDriver dr;
 public all_webelement_fns(WebDriver dr) 
{
	this.dr=dr;
}
public void enter_text(String xp, String data)
{
dr.findElement(By.xpath(xp)).sendKeys(data);	
}
public void click(String xp)
{
	dr.findElement(By.xpath(xp)).click();
}
public void launchChrome(String url)
{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr=new ChromeDriver();
	dr.get(url);
}

//public void verify(String loc,String exp_value)
//{
//	String test_result;
//	String act_value= dr.findElement(By.xpath(loc)).getText();
//	if(act_value.equals(exp_value))
//}

}

