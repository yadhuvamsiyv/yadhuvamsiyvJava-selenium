package Day_04;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class excel_operations {
String filename="C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\ExcelFile.xlsx", sheetname="Data";
	
	
	public String read_excel(int row, int col) {
		String s=null;
		try {
			File f = new File(filename);
			 FileInputStream fis = new  FileInputStream(f);
			 XSSFWorkbook wb = new  XSSFWorkbook(fis);
			 XSSFSheet sh= wb.getSheet(sheetname);
			 XSSFRow r=sh.getRow(0);
			 XSSFCell c=r.getCell(0);
			  s = c.getStringCellValue();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return(s);
	}
}
