package Day_04;

import org.openqa.selenium.WebDriver;

public class driver_script {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String low,loc,td;
WebDriver dr=null;
all_webelement_fns we=new all_webelement_fns(dr);
excel_operations excel = new excel_operations();
for(int r=1;r<=4;r++)
{
	low = excel.read_excel(r,2);
	loc = excel.read_excel(r,3);
	td = excel.read_excel(r,4);
	switch(low)
	{
	case "launchBrowser" :
		we.launchChrome(td);
		break;
	case "enterText":
		we.enter_text(loc,td);
		break;
		
	case "click":
		we.click(loc);
		break;
			}
}
	}

}
