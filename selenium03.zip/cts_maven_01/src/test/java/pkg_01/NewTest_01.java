package pkg_01;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class NewTest_01 {
  @Test
  public void f() {
	  System.out.println("in testing");
	  System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
 WebDriver dr=new FirefoxDriver();
	  dr.get("https://www.saucedemo.com/");
  }
}
