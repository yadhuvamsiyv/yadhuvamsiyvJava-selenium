package DAY_1;

public class Pgm1 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int i=10;
		int j=20;
		
		System.out.println(i>j);
		System.out.println(i==10);
		

	}

}
