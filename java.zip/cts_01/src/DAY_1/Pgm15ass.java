package DAY_1;

public class Pgm15ass {

	public static void main(String[] args) {
		  int a=1234589,b=0;
	        while(a>0)
	        {
	            b++;
	            a/=10;
	        }
	        System.out.println(b);

	    }

	}

	

