package DAY_1;

public class Pgm7ass {

	public static void main(String[] args) 
	{
		int i,rem;
		for(i=1;i<=10;i++)
		{
			rem=i%2;
			if(rem==0)
				System.out.println(i);
		}

	}

}
