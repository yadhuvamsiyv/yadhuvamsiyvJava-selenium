package DAY_1;

public class Pgm12ass {

	public static void main(String[] args)
	{
	int k,j=4;
	for(int i=5;i<=9;i++)
	{
		System.out.println(i + "*" +j+"="+(i*j));
		j=j+2;
	}

	}

}
