package DAY_1;

public class Pgm4_1ass 
{

	public static void main(String[] args) 
	
	{
	
		int a=21,b=8,c=17;
		
		if(a<b&&a<c )
		
		{
			System.out.println(a);
		}
		
		
		
		else if(b<a&&b<c)
		{
			System.out.println(b);
		}
		
		
		
		else
		{
			System.out.println(c);
		}
	
	
	}
	

}
