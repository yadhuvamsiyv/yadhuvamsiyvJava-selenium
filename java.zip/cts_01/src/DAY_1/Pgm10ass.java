package DAY_1;

public class Pgm10ass {

	public static void main(String[] args)
	{
		int sum=0,r,n=59138;
		while(n>0)
		{
			r=n%10;
			if(r>5)
			{
				sum=sum+r;
			}
			n=n/10;
		}
System.out.println(sum);
	}

}
