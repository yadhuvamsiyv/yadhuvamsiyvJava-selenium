package DAY_1;

public class Pgm13ass 
{

	public static void main(String[] args) 
	{
		
	int n=1,first=0,next=1;
	
	for(int i=1;i<n-1;i++)
	{
int sum=first +next;
first=next;
next=sum;
System.out.println(sum);

	}

}
}