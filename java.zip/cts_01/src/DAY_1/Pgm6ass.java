package DAY_1;

public class Pgm6ass {

	public static void main(String[] args)
	{
		int i=30;
		switch(i)
		{
		case 10:
			System.out.println("ten");
			break;
		case 20:
			System.out.println("twenty");
			break;
			default:
				System.out.println("no value");
		}
		}

}
