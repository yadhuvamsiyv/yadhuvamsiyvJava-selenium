package DAY_1;

public class Pgm4_2ass 
{

	public static void main(String[] args) 
	
	{
		int a=15,b=10,c=4;
		if(a<b)
		{
			System.out.println(a);
		}
		else if(b<c)
		{
			System.out.println(b);
		}
		else 
		{
			System.out.println(c);
		}
	}
	

}
