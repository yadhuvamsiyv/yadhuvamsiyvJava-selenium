package DAY_1;

public class Pgm5ass {

	public static void main(String[] args)
	{
	long sal=35000,tax,taxpay;

	
	if((sal>=0)&&(sal<=180000))
	{
		
		System.out.println("tax is 0");
	}
	else if((sal>180001)&&(sal<=500000))
	{
		tax=sal-180000;
		taxpay=(tax*10)/100;
		System.out.println(taxpay);
	}
	else if((sal>500001)&&(sal<=800000))
	{
		tax=sal-500000;
		taxpay=(tax*20)/100;
		System.out.println(taxpay);
	}
	else if(sal>=800001)
	{
		tax=sal-800000;
		taxpay=(tax*30)/100;
		System.out.println(taxpay);
	}
	
	}

}
