package DAY_3;

public class animal 
{
	int height,weight,age;
	char gender;
	String colour;
public void display()
	{
		System.out.println("height: " + height +"weight: " + weight+"age: " + age+"gender: " + gender+"colour: " + colour);
	}
	
}
