package DAY_3;

import java.util.Scanner;

public class Pgm2ass {

	public static void main(String[] args)
	{
		int c=1;
String emp[][]={{"01","vamsi"},{"02","yadhu"},{"03","radha"},{"04","vanitha"},{"05","raju"}};		
System.out.println("Enter empid : ");
Scanner input = new Scanner(System.in);
String emp_id=input.nextLine();
for(int i=0;i<=4;i++)
{
	for(int j=0;j<=1;j++)
	{
		c=emp_id.compareTo(emp[i][j]);
		if(c==0)
		{System.out.println(emp[i][j+1]);
	}
}
	}

	}}
