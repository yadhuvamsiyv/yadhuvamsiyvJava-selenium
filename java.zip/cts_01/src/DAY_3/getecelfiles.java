package DAY_3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class getecelfiles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		


		try

		{
			File f = new File("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\xyz.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Test Scenario");
			XSSFRow row = sh.getRow(0);
			XSSFCell cell = row.getCell(0);
			XSSFSheet sh1 = wb.getSheet("Test cases");
			XSSFRow r = sh1.getRow(0);
			XSSFCell c = r.getCell(0);
			
			cell.setCellValue("chennai");
			c.setCellValue("Bangalore");
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			}

		

	}


