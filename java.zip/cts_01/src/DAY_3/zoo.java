package DAY_3;

public class zoo {

	public static void main(String[] args)
	{
		elephant e1= new elephant();
		e1.height=8;
		e1.weight=200;
		e1.colour="grey";
		e1.gender='m';
		e1.lotrunk=10;
		e1.lotusk=20;
e1.display();
	}

}
