package DAY_3;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i;
float f;
student ramesh=new student();
ramesh.java=80;
ramesh.selenium=90;
ramesh.cal_avg();
System.out.println("average marks of ramesh = "+ramesh.avg);


student priya=new student();

priya.java=80;
priya.selenium=90;
priya.cal_avg();
System.out.println("average marks of priya = "+priya.avg);
	}

}
