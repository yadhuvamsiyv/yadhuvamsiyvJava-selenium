package DAY_3;

public class library
{
public float add(int x,float y)
{
	float z=x+y;
	System.out.println(z);
	return z;}
public int power(int x, int y)
{
	int pow=1;
	for(int i=1;i<=y;i++){
	pow=pow*x;
	}
	return pow;
}
}
