package DAY_3;

public class elephant extends animal{
	int lotrunk,lotusk;
	public void display_details()
	{
		super.display();
		System.out.println("lotrunk: "+lotrunk + "lotusk: "+lotusk);
	}

}
