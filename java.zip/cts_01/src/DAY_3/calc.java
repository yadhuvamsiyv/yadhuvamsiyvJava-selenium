package DAY_3;

public class calc extends library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calc c=new calc();
		float d=c.add(3, 5.0f);
		System.out.println("Addition : " + d);
		int a=c.power(2, 3);
		System.out.println("power : " + a);

	}

}
