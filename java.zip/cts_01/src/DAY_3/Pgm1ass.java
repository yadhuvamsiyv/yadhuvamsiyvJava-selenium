package DAY_3;
import java.util.Scanner;
public class Pgm1ass {

	public static void main(String[] args)
	{
		int count=0;
		char c='a';
		System.out.println("enter a string : ");
		Scanner s = new Scanner(System.in);
		
		while(c!='n')
		{
			c=s.next().charAt(0);
		if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
		{
			count++;
		}
	
		}
		System.out.println(count);
}
}
