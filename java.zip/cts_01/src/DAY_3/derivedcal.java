package DAY_3;


	public class derivedcal extends bascal {
		public void mul()
		{
			
			num=num1*num2;
			System.out.println(num);
		}
		}

