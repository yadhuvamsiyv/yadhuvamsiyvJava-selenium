package DAY_4;

public class student {
int id;
String name;
int selenium;
int java;
float avg;
public student (int s ,int j)
{
	System.out.println("object created");
	java=j; selenium=s;
}


public void calc_avg()
{
	avg=(selenium + java )/2.0f;
}
}
