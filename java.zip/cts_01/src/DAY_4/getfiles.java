package DAY_4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;





public class getfiles {

	public static void main(String[] args) {
		
try
{
	
	
	
File f = new File("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\xyz.xlsx");
FileInputStream fis= new FileInputStream(f);
XSSFWorkbook wb= new XSSFWorkbook(fis);
XSSFSheet s1 = wb.getSheet("Test Scenario");
XSSFRow r1 = s1.getRow(0);
XSSFCell c1 = r1.getCell(0);
String sh= c1.getStringCellValue();



XSSFSheet s2 = wb.getSheet("Test cases");
XSSFRow r2 = s2.getRow(0);
XSSFCell c2 = r2.getCell(0);
 
c2.setCellValue(sh);
FileOutputStream fos = new FileOutputStream(f);
wb.write(fos);
}


catch
(FileNotFoundException e)
{
	e.printStackTrace();
}
catch
(IOException e) {
	e.printStackTrace();
	}
}
	}


