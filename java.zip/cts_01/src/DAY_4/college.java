package DAY_4;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i;
float f;
student ramesh=new student(80,90);


/*ramesh.java=80;
ramesh.selenium=90;*/

ramesh.calc_avg();
System.out.println("average marks of ramesh = "+ramesh.avg);


student priya=new student(90,50);

/*priya.java=80;
priya.selenium=90;*/


priya.calc_avg();
System.out.println("average marks of priya = "+priya.avg);
	}

}
