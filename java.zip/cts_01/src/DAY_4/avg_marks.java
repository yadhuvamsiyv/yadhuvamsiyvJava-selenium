package DAY_4;

import java.util.Scanner;

public class avg_marks 
{
	
	static String[][] sid ={{"1","vamsi"},{"2","yadhu"},{"3","radha"},{"4","vanitha"},{"5","raju"}};	
	static int[][] marks = {{1,50,80},{3,55,85},{2,95,87},{5,45,75},{4,85,74}};

public static int calc_avg(int a, int b)
{
	int avg=(a+b)/2;
	return avg;
}


public static int search1(int ssid)
{
	int i,j=0;
	for(i=0;i<5;i++)
	{
		int d=Integer.parseInt(sid[i][j]);
		if (ssid==d)
		{
			break;
		}
	}
	
	return i;
}


public static int search2(int ssid)
{
	int i,j=0;
	for(i=0;i<5;i++)
	{
		if (ssid==marks[i][j])
		{
			break;
		}
		
	}
	
	return i;
}
	public static void main(String[] args) {
		
		int i,j=0;
				System.out.println("enter sid");
		Scanner input =new Scanner(System.in);
		int ssid=input.nextInt();
		
		
		
		i=search1(ssid);
	
		
		
		
		System.out.println(ssid);
		System.out.println(sid[i][j+1]);
		System.out.println(calc_avg(marks[search2(ssid)][j+1],marks[search2(ssid)][j+2]));
		
		}

}

