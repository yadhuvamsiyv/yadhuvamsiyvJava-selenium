package DAY_4;

public class pgm2calc 
{
public int add(int x,int y)
{
	int z=x+y;
	System.out.println("2 params");
	return z;
}
public int add(int a,int b,int c)
{
	int d=a+b+c;
	System.out.println("3 params");
	return d;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
pgm2calc calc= new pgm2calc();
int m = calc.add(3,4);
int m2= calc.add(2,3,5);
System.out.println(m);
System.out.println(m2);
	}

}
