package DAY_4;

public class pgm1ass
{
	
	public static int avg(int x,int y)
	{
	int	 c=(x+y)/2;
		return c;
	}
	
	public static int search(String std)
	{
		int i=Integer.parseInt(std);
		return i;
	}
	
	
	
public static void main(String[] args) 
	{
		String[][] std ={{"01","vamsi"},{"02","yadhu"},{"03","radha"},{"04","vanitha"},{"05","raju"}};	
		int[][] marks = {{01,50,80},{02,55,85},{03,95,87},{04,45,75},{05,85,74}};
		pgm1ass p = new pgm1ass();
		System.out.println("id "+"name "+"avg ");
		
		for(int i=0;i<5;i++)
		{
			int m=p.search(std[i][0]);
						if(m==marks[i][0])
			{
				int R=p.avg(marks[i][1],marks[i][2]);
				System.out.println(std[i][0]+" "+std[i][1]+" "+R);
			}
		}
	}

}
