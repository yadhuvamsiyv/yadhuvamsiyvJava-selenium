package DAY_2;

public class Pgm12ass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hello, how are you?";
		int count=0;
		for(int i=0;i<=str.length()-1;i++)
		{
			if(str.charAt(i)=='o') {
				count++;
			}
		}
		System.out.println(count);
	}

}

	
