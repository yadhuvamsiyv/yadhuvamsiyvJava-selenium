package DAY_2;

public class Pgm7 {

	public static void main(String[] args)
	{
		int a=10,b=0,c;
		int[]m={1,3,5,6};
		try
		{
			System.out.println("before");
			c=a/b;
			System.out.println("after");
		}
		catch(Exception e)
		{
		System.out.println("in catch blk");
	}	// TODO Auto-generated method stub
System.out.println(m[53]);
	}

}
