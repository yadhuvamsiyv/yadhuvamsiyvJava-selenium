package DAY_2;

public class Pgm2 {

	public static void main(String[] args) 
	{
		int[] marks={95,96,51,80,43,60,50,81};
		int i,sum=0;
		for(i=0;i<=7;i=i+2)
		{
			if(marks[i]%2!=0)
			sum+=marks[i];
		}
System.out.println(sum);
	}

}
