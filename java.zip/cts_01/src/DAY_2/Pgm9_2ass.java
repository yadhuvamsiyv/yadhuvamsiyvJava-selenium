package DAY_2;

public class Pgm9_2ass {

	public static void main(String[] args) 
	{

		int[][]m={{18,4,2},{22,55,2},{22,6,7}};
		int i,j,max=0;
	
	for(i=0;i<3;i++)
		{
		
			for(j=0;j<3;j++)
				
			{
				if(m[i][j]>max)
					max=m[i][j];
				
			}
		
		System.out.println(max);
		
		}
           
		
	

	}

}
