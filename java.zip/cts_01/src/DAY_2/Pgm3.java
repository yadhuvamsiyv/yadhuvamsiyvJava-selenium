package DAY_2;

public class Pgm3 {

	public static void main(String[] args) 
	{
		int s=0;
	int[][] m={{75,85,80},{81,91,95}};
	for(int r=0;r<=1;r++)
	{
		for(int c=0;c<=2;c++)
		{
			if(m[r][c]%2==0)
			s = s+m[r][c];
		}
	}
System.out.println(s);
	}

}
