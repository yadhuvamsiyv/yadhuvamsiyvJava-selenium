package DAY_2;

public class Pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="Chennai",s1="Chennai",s2="chennai", s3;
	int l=s.length();
	int v=s.compareTo(s2);
	System.out.println("length = " +l + "return value :"+v);
	
	
	int rv=s.compareToIgnoreCase(s2);
	System.out.println("rv="+rv);
	
	s3=s.substring(0,4);
	System.out.println("substring : "+s3);
	
	int p=s.indexOf("n",0);
	System.out.println("position: "+ p);
	
	int p1=s.indexOf("n",p+1);
	System.out.println("Position of 2nd n: "+p1);
	
	
	
	
	}
}
