package DAY_2;

public class Pgm6 {

	public static void main(String[] args) 
	{
		

	
		String s="i am learning core java";
		int p=0,c=0,i=0,p1=0;
        String s1;
	while(p1!=-1)
		{
		p=s.indexOf(" ",i);
		p1=p;
		
	c++;
	if(p==-1)
	
		p=s.length();
	
	s1=s.substring(i,p);
	i=p+1;
	
	System.out.println(s1);
		}
	}
}