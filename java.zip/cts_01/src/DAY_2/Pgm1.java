package DAY_2;

public class Pgm1 {

	public static void main(String[] args)
	{
		int[] marks={95,90,50,60,90,90,71,81};
		int sum=0;
		float avg;
		for(int i=0;i<=7;i++)
		{
			sum=sum+marks[i];
		
		}
avg=sum/8f;
System.out.println(avg);

if(avg>=70)
{
	System.out.println("firstclass distinction");
}

else if((avg>=60)&&(avg<70))
{
	System.out.println("fisrtclass");
}

else if ((avg>=50)&&(avg<60))
{
	System.out.println("second class");
}
		
	}
}
