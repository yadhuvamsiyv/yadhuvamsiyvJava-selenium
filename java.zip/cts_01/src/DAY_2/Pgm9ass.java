package DAY_2;

public class Pgm9ass {

	public static void main(String[] args) 
	{
		int[] m={18,4,2,29,55,84,75};
		int largest;
		largest=m[1];
		
	int i=0;
	while(i<7)
	{
			if(m[i]>largest)
			largest=m[i];
	i++;
		}
		System.out.println(largest);
		}
	
	
		
		}

	


