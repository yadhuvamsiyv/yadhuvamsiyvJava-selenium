package DAY_5;

import java.util.ArrayList;

public class araylist 
{
ArrayList<student> std= new ArrayList<student>();
public void create()
{
	student s1 = new student("vamsi",01,80,55);
	student s2 = new student("raju",02,55,65);
	student s3 =new student("balu",03,55,70);
	std.add(s1);
	std.add(s2);
	std.add(s3);
}

public void display()
{
	for(student s : std)
	{
		System.out.println(s.name + " "+s.id + " "+s.selenium +" "+ s.java );
	}
}
public static void main(String[] args)
{
	araylist a=new araylist();
	a.create();
	a.display();
}
} 
