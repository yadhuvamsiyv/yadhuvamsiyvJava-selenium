package DAY_5;

public class xl {

	public static void main(String[] args) {
		String Sheet1;
		
		excel2 g=new excel2();
		Sheet1=g.readexcel("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\xyz.xlsx", "Test Scenario",0,0);
		g.write("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\xyz.xlsx", "Test cases",0,0,"i am vamsi");
		System.out.println(Sheet1);
	}

}
