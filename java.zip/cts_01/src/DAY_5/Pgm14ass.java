package DAY_5;

public class Pgm14ass {

	public static void main(String[] args) 
	{

		 
		        int num=11,count=0;
		        int i=2;
		        while(i<num)
		        {
		        	if (num%i==0)
		        	{
		        		count++;
		        	}
		        i++;
		        }
		        
		        if(count==0)
		        {
		     System.out.println("prime");
		        	}
		     else
		     {
		    	 System.out.println("not prime");
		     }



		        }
	}

		        
		    




