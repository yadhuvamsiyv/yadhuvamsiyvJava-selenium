package DAY_5;

public class student {

	String name;
	int id;
	int selenium;
	int java;
	
		// TODO Auto-generated method stub
		
		
		public student(String name, int id,int selenium, int java)
		{
			this.name=name;
			this.id=id;
			this.selenium=selenium;
			this.java=java;
		}

		
		
	}


