package DAY_5;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class pgm1 {

	public static void main(String[] args) {
		try
		
		{
			FileInputStream fin=new FileInputStream("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\vamsi.txt");
			
	int i;
	//i=fin.read();
	//System.out.println((char)i);
	
	
	/*while((i=fin.read())!=-1)
	{
		System.out.println((char)i);
	}*/
	fin.close();
	FileOutputStream fos = new FileOutputStream("C:\\Users\\BLTuser.BLT0214\\Desktop\\New folder\\vamsi.txt");
		byte[] d= "i am learning java".getBytes();
		fos.write(d);
fos.close();		
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		
		}
		
	}


