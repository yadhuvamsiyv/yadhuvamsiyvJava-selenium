package DAY_5;

import java.util.ArrayList;

public class arraylist {

	public static void main(String[] args) {
		
		ArrayList<String> str_a=new ArrayList<String>();
		str_a.add("hgh");
	
		str_a.add("vamsi");
		str_a.add("yadhu");
		str_a.add("jjd");
		System.out.println("Before insertion : " +str_a);
	
		str_a.add(3,"mani");
		System.out.println("after insertion : " +str_a);
		str_a.remove(1);
		System.out.println("after insertion : " +str_a);
	
		for (String s:str_a)
		{
			System.out.println(s);
		}
	}
	

}
