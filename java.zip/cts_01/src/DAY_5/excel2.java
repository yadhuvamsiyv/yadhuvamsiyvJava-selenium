package DAY_5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel2 {

	
		public String readexcel (String fname, String name, int r, int c)
		{
		String s=null;
		 try 
		 {
			 File f = new File(fname);
			 FileInputStream fis = new  FileInputStream(f);
			 XSSFWorkbook wb = new  XSSFWorkbook(fis);
			 XSSFSheet sh= wb.getSheet(name);
			 XSSFRow row=sh.getRow(0);
			 XSSFCell cell=row.getCell(0);
			  s = cell.getStringCellValue();
			
			 
		 }
		 
		 catch (IOException e)
		 {
			 e.printStackTrace();
		 }
			 return s;
	
		}
		public void write (String fname, String name, int r, int c,String str)
		{
		String s=null;
		 try 
		 {
			 File f = new File(fname);
			 FileInputStream fis = new  FileInputStream(f);
			 XSSFWorkbook wb = new  XSSFWorkbook(fis);
			 XSSFSheet sh= wb.getSheet(name);
			 XSSFRow row=sh.getRow(0);
			 XSSFCell cell=row.getCell(0);
			  
			 cell.setCellValue(str);
			 FileOutputStream fos = new FileOutputStream(f);
			 wb.write(fos);
		 }
		 
		 catch (IOException e)
		 {
			 e.printStackTrace();
}
		}
}
		
