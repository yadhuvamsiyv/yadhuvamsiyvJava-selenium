package DAY_5;

public class testbank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
bank b;
b= new icici();
System.out.println("icici : " +b.get_roi());

b=new hdfc();
System.out.println("hdfc : "+b.get_roi());
	}

}
